#include <stdio.h>
#include <stdlib.h>
#include "node.h"

int main() {
    Node *raiz = NULL;
    raiz = inserir(raiz, 25);
    inserir(raiz, 22);
    inserir(raiz, 40);
    inserir(raiz, 30);
    inserir(raiz, 45);
    inserir(raiz, 27);
    inserir(raiz, 20);

    printf("\n----------\n");
    printf("Pre ordem");
    printf("\n----------\n");
    preOrdem(raiz);

    printf("\n----------\n");
    printf("Pos ordem");
    printf("\n----------\n");
    posOrdem(raiz);

    return 0;
}