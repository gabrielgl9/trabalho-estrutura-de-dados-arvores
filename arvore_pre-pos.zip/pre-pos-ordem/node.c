#include <stdio.h>
#include <stdlib.h>
#include "node.h"

Node *inserir (Node *raiz, int novoValor) {
    if (raiz == NULL)  {
        return criar(novoValor);
    }
    if (novoValor < raiz->valor ) {
        raiz->esq = inserir(raiz->esq, novoValor);
    }
    if (novoValor > raiz->valor ) {
        raiz->dir = inserir(raiz->dir, novoValor);
    }
    return raiz;
}

Node *criar (int novoValor) {
    Node *temp = (Node*)malloc(sizeof(Node));
    temp->valor = novoValor;
    temp->esq = temp->dir = NULL;
    return temp;
}

void preOrdem (Node *raiz) {
    if (raiz != NULL) {
        printf("%d\n", raiz->valor);
        preOrdem(raiz->esq);
        preOrdem(raiz->dir);
    }
}

void posOrdem (Node *raiz) {
    if (raiz != NULL) {
        posOrdem(raiz->esq);
        posOrdem(raiz->dir);
        printf("%d\n", raiz->valor);
    }
}