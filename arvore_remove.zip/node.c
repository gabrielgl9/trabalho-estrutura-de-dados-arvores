#include <stdio.h>
#include <stdlib.h>
#include "node.h"

Node *inserir (Node *raiz, int novoValor) {
    if (raiz == NULL)  {
        return criar(novoValor);
    }
    if (novoValor < raiz->valor ) {
        raiz->esq = inserir(raiz->esq, novoValor);
    }
    if (novoValor > raiz->valor ) {
        raiz->dir = inserir(raiz->dir, novoValor);
    }
    return raiz;
}

Node *criar (int novoValor) {
    Node *temp = (Node*)malloc(sizeof(Node));
    temp->valor = novoValor;
    temp->esq = temp->dir = NULL;
    return temp;
}

void preOrdem (Node *raiz) {
    if (raiz != NULL) {
        printf("%d\n", raiz->valor);
        preOrdem(raiz->esq);
        preOrdem(raiz->dir);
    }
}

void mostrarArvore (Node *raiz) {
    if (raiz != NULL) {
        printf("%d\n", raiz->valor);
        mostrarArvore(raiz->esq);
        mostrarArvore(raiz->dir);
    }
}

void removerMaior (Node *raiz) {
  Node *aux = raiz;
  Node *maior = raiz;
  
  while (aux->dir != NULL) {
    if (aux->dir->dir == NULL) {
      maior = aux->dir;
      aux->dir = NULL;
    } else {
      aux = aux->dir;
    }
  }

  free(maior);
}

void removerMenor (Node *raiz) {
  Node *aux = raiz;
  Node *menor = raiz;
  while (aux->esq != NULL) {
    if (aux->esq->esq == NULL) {
      menor = aux->esq;
      aux->esq = NULL;
    } else {
      aux = aux->esq;
    }
  }
  free(menor);
}