#include <stdio.h>
#include <stdlib.h>
#include "node.h"

int main() {
    Node *raiz = NULL;
    raiz = inserir(raiz, 25);
    inserir(raiz, 22);
    inserir(raiz, 40);
    inserir(raiz, 30);
    inserir(raiz, 45);
    inserir(raiz, 24);
    inserir(raiz, 20);

    printf("\n------------------------\n");
    printf(" MOSTRA A RAIZ COMPLETA ");
    printf("\n------------------------\n");
    mostrarArvore(raiz);

    printf("\n------------------------\n");
    printf(" REMOVE O MAIOR NUMERO ");
    printf("\n------------------------\n");
    removerMaior(raiz);
    mostrarArvore(raiz);
    
    printf("\n------------------------\n");
    printf(" REMOVE O MENOR NUMERO ");
    printf("\n------------------------\n");
    removerMenor(raiz);
    mostrarArvore(raiz);

    return 0;
}